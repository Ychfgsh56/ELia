/**
 * BlackDev Project
 * Developer: o_3_m_a_r
 * YouTube: https://www.youtube.com/@BlackDev_0
 * Discord: https://discord.com/invite/mQAWTNrcNQ
 * Copyright © o_3_m_a_r. All Rights Reserved.
 */

require('dotenv').config({ debug: false });

const logger = require('./Utils/logger');
const startBot = require('./core/startBot');
const { ensureDatabase } = require('./Utils/database');
const errorHandler = require('./Utils/errorHandler');

// Shared project utilities
global.logger = logger;
global.errorHandler = errorHandler;

ensureDatabase();
require('./lib/state');

process.on('unhandledRejection', reason => {
  logger.error('❌ Unhandled Rejection:', reason);
});

process.on('uncaughtException', error => {
  logger.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

async function gracefulShutdown() {
  logger.info('🛑 Starting safe bot shutdown...');

  if (global.client && typeof global.client.destroy === 'function') {
    try {
      await global.client.destroy();
    } catch (err) {
      logger.error('❌ Error shutting down bot:', err);
    }
  }

  process.exit(0);
}

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

async function start() {
  try {
    if (!process.env.TOKEN) {
      throw new Error('❌ لم يتم العثور على TOKEN في ملف .env');
    }

    logger.info('💾 Local JSON database ready: data/invites.json, data/prizes.json, data/serverConfigs.json');
    logger.info('🚀 Starting main bot...');

    global.client = await startBot(process.env.TOKEN);
  } catch (err) {
    logger.error('❌ خطأ في البدء:', err);
    process.exit(1);
  }
}

start();
