# حقوق المشروع

- المبرمج: **o_3_m_a_r**
- YouTube: https://www.youtube.com/@BlackDev_0
- Discord: https://discord.com/invite/mQAWTNrcNQ

**Copyright © o_3_m_a_r. All Rights Reserved.**

لا يجوز إعادة نشر المشروع أو بيعه أو نسبه إلى جهة أو شخص آخر دون إذن من المبرمج.
