const { CREDITS } = require('./Utils/credits');
const { ActivityType } = require('discord.js');

module.exports = {
  credits: CREDITS,
  ownerShip: '900860289443045437',
  status: {
    initialStatus: 'dnd',
    interval: 15000,

    defaultStatuses: [
      { name: '-help', type: ActivityType.Playing },
      { name: '/help', type: ActivityType.Playing },
      { name: 'Dev : o_3_m_a_r', type: ActivityType.Listening }
    ]
  }

};