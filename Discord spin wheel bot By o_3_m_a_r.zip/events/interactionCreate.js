const { PermissionsBitField, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { handleSpinInteraction } = require('../handlers/buttonHandlers');
const logger = require('../Utils/logger');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction) {
    const safeReply = async options => {
      try {
        if (interaction.replied || interaction.deferred) {
          return await interaction.followUp(options);
        }
        return await interaction.reply(options);
      } catch (err) {
        if (err?.code === 10062) return;
        throw err;
      }
    };

    try {
      if (interaction.isButton()) {
        const id = interaction.customId;

        if (id === 'help_explain') {
          return safeReply({
            content: `نظام الدعوات والعجلة

عند انضمام عضو عبر رابط دعوة:
• يحصل الداعي على نقطة.

إذا كان الحساب جديدًا أقل من العمر المحدد:
• لا تُحتسب الدعوة.

يمكن استخدام النقاط في:
• تدوير العجلة للحصول على جوائز.

كل سيرفر يمكنه تحديد:
• نقاط كل نوع من العجلة
• عمر الحساب المطلوب
• قنوات السجل`,
            flags: [MessageFlags.Ephemeral]
          });
        }

        if (id === 'help_commands') {
          return safeReply({
            content: `الأوامر

/point | -point | -points
عرض نقاط الدعوات.

/addpoint | -addpoint
إضافة نقاط لمستخدم.

/removepoint | -removepoint
إزالة نقاط من مستخدم.

/reset | -reset
إعادة ضبط النقاط.

/spin | -spin
لف عجلة الجوائز.

/setspincost
تحديد نقاط كل نوع من العجلة.

/setlogchannels
تحديد قنوات السجل.

/setage
تحديد العمر الأدنى للحساب.

/wheel-style
تحديد شكل العجلة.`,
            flags: [MessageFlags.Ephemeral]
          });
        }

        if (id === 'normal_spin' || id === 'special_spin') {
          return handleSpinInteraction({
            interaction,
            getUserInvites: db.getUserInvites,
            getServerConfig: db.getServerConfig,
            getPrizes: db.getPrizes,
            updateUserInvites: db.updateUserInvites
          });
        }

        return;
      }

      if (interaction.isAutocomplete()) {
        const autocomplete = interaction.client.slashAutocomplete?.get(interaction.commandName);
        if (typeof autocomplete === 'function') {
          try {
            return await autocomplete(interaction);
          } catch (err) {
            logger.error('❌ Error in autocomplete:', err);
            return interaction.respond([]).catch(() => {});
          }
        }
        return;
      }

      if (interaction.isCommand()) {
        if (!interaction.channel || !interaction.channel.permissionsFor(interaction.client.user)?.has([
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages
        ])) {
          return safeReply({
            content: '❌ لا أملك صلاحية إرسال الرسائل في هذه القناة.',
            flags: [MessageFlags.Ephemeral]
          });
        }

        const command = interaction.client.slashCommands.get(interaction.commandName);
        if (command && typeof command.execute === 'function') {
          try {
            return await command.execute(interaction);
          } catch (err) {
            logger.error(`❌ Error executing /${interaction.commandName}:`, err);
            return safeReply({
              content: '❌ حدث خطأ أثناء تنفيذ الأمر.',
              flags: [MessageFlags.Ephemeral]
            });
          }
        }

        return safeReply({
          content: `❌ الأمر \`/${interaction.commandName}\` غير موجود.`,
          flags: [MessageFlags.Ephemeral]
        });
      }
    } catch (err) {
      logger.error('❌ Error in interactionCreate:', err);
      await safeReply({
        content: '❌ حدث خطأ أثناء معالجة الطلب.',
        flags: [MessageFlags.Ephemeral]
      }).catch(() => {});
    }
  }
};
