const { cachedInvites, leaveTracking } = require('../lib/state');
const { getUserInvites, updateUserInvites, getServerConfig } = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');
const { MessageFlags } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  once: false,

  async execute(member) {
    try {
      const guild = member.guild;

      if (!guild.members.me?.permissions.has('ManageGuild')) {
        console.log(`⚠️ Bot lacks ManageGuild permission in ${guild.name}, cannot track invites`);
        return;
      }

      let newInvites;
      try {
        newInvites = await guild.invites.fetch();
      } catch (err) {
        console.error(`Failed to fetch invites for guild ${guild.id}:`, err.message);
        return;
      }

      const cachedGuildInvites = cachedInvites.get(guild.id) || new Map();
      let inviterId = null;

      for (const invite of newInvites.values()) {
        const oldUses = cachedGuildInvites.get(invite.code) || 0;
        if (invite.uses > oldUses) {
          inviterId = invite.inviter?.id;
          if (inviterId) {
            console.log(`✅ Found inviter: ${inviterId} for member ${member.user.tag} using invite code ${invite.code}`);
          }
          break;
        }
      }

      cachedInvites.set(
        guild.id,
        new Map(newInvites.map(invite => [invite.code, invite.uses]))
      );

      if (leaveTracking.has(`${member.id}-${guild.id}`)) {
        leaveTracking.delete(`${member.id}-${guild.id}`);
        console.log(`ℹ️ Member ${member.user.tag} rejoined, not counting as new invite`);
        return;
      }

      const config = await getServerConfig(guild.id);
      let minMonths = Number(config?.minAccountAgeMonths || 1);
      if (!Number.isFinite(minMonths) || minMonths < 0) minMonths = 1;

      const minAgeMs = minMonths * 30 * 24 * 60 * 60 * 1000;
      const accountAgeMs = Date.now() - member.user.createdTimestamp;
      const isTooNew = accountAgeMs < minAgeMs;

      if (isTooNew) {
        console.log(`⚠️ Member ${member.user.tag} account too young (${Math.floor(accountAgeMs / (1000 * 60 * 60 * 24))} days), minimum ${minMonths} months`);

        if (inviterId && config?.inviteLogChannelId) {
          const logChannel = await guild.client.channels.fetch(config.inviteLogChannelId).catch(() => null);
          if (logChannel) {
            const accountAgeDays = Math.floor(accountAgeMs / (1000 * 60 * 60 * 24));
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(t => t.setContent('حساب جديد'));
            container.addSeparatorComponents(s => s.setSpacing(1));
            container.addTextDisplayComponents(t => t.setContent(
              `العضو: <@${member.user.id}>\nالداعي: <@${inviterId}>\nعمر الحساب: ${accountAgeDays} يوم\nالعمر المطلوب: ${minMonths} شهر\n\nلم تُحتسب الدعوة.`
            ));
            await logChannel.send({ ...container.build(), flags: [MessageFlags.IsComponentsV2] }).catch(() => null);
          }
        }
        return;
      }

      if (!inviterId) {
        console.log(`⚠️ No inviter found for member ${member.user.tag} in guild ${guild.name}`);
        return;
      }

      const currentInvites = await getUserInvites(inviterId, guild.id);
      const credited = await updateUserInvites(inviterId, guild.id, currentInvites + 1, member.id);

      console.log(`✅ Updated invites for ${inviterId}: ${currentInvites} → ${currentInvites + 1}`);

      if (!config?.inviteLogChannelId) return;

      const logChannel = await guild.client.channels.fetch(config.inviteLogChannelId).catch(() => null);
      if (!logChannel) return;

      const container = new ContainerBuilder();
      let title;
      let text;

      if (credited?.credited === true) {
        title = 'انضمام عضو';
        text = `العضو: <@${member.user.id}>\nالداعي: <@${inviterId}>\nالنقاط: ${currentInvites} → ${currentInvites + 1}`;
      } else if (credited?.existingInviterId) {
        title = 'دعوة محسوبة مسبقًا';
        text = `العضو: <@${member.user.id}>\nتم احتسابه سابقًا لصالح: <@${credited.existingInviterId}>`;
      } else {
        title = 'عودة عضو';
        text = `العضو: <@${member.user.id}>\nعاد إلى السيرفر\nالداعي: <@${inviterId}>`;
      }

      container.addTextDisplayComponents(t => t.setContent(title));
      container.addSeparatorComponents(s => s.setSpacing(1));
      container.addTextDisplayComponents(t => t.setContent(text));

      await logChannel.send({ ...container.build(), flags: [MessageFlags.IsComponentsV2] }).catch(() => {});
    } catch (err) {
      console.error('Error in guildMemberAdd:', err);
      global.errorHandler?.handleError(err, `guildMemberAdd: ${member.guild?.name}`, {
        userId: member.id,
        guildId: member.guild?.id
      });
    }
  }
};
