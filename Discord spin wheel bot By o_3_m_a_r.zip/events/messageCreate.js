const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'messageCreate',
  once: false,

  async execute(message) {
    try {

      if (message.author.bot) return;

      // تحذير إذا Message Content غير مفعل
      if (!message.content || message.content.trim() === '') {
        if (!message.client._warnedMissingMessageContent) {
          message.client._warnedMissingMessageContent = true;
          global.logger?.warn(
            `Message content appears empty for bot ${message.client.user?.tag}`
          );
        }
        return;
      }

      const PREFIX = '-';

      if (!message.content.startsWith(PREFIX)) return;

      const args = message.content
        .slice(PREFIX.length)
        .trim()
        .split(/ +/g);

      const commandName = args.shift()?.toLowerCase();

      if (!commandName) return;

      let command = message.client.commands.get(commandName);

      if (!command && message.client.aliases) {
        const real = message.client.aliases.get(commandName);
        if (real) command = message.client.commands.get(real);
      }

      if (!command) return;

      if (typeof command.execute !== 'function') {
        global.logger?.error(`الأمر ${commandName} بدون execute`);
        return message.reply({
          content: 'حدث خطأ.'
        }).catch(() => {});
      }

      await command.execute(message, args);

    } catch (err) {

      global.errorHandler?.handleMessageError(
        message,
        err,
        message.content.split(/\s+/)[0]
      );

    }
  }
};