const logger = require('../Utils/logger');
const { cachedInvites } = require('../lib/state');
const config = require('../config');

module.exports = {
  name: 'ready',
  once: true,

  async execute(client) {
    try {
      logger.success(`✅ Main bot logged in: ${client.user?.tag || 'Unknown'}`);
      await initializeCachedInvites(client);
      await registerSlashCommands(client);
      startStatusRotation(client);
    } catch (error) {
      global.errorHandler?.handleError(error, 'ready event');
    }
  }
};

async function initializeCachedInvites(client) {
  try {
    for (const guild of client.guilds.cache.values()) {
      if (!guild.members.me?.permissions.has('ManageGuild')) {
        logger.warn(`⚠️ Bot lacks ManageGuild permission in ${guild.name}, skipping invite cache`);
        continue;
      }

      try {
        const invites = await guild.invites.fetch();
        cachedInvites.set(
          guild.id,
          new Map(invites.map(invite => [invite.code, invite.uses || 0]))
        );
      } catch (err) {
        logger.warn(`⚠️ Failed to fetch invites for ${guild.name}: ${err.message}`);
      }
    }
  } catch (err) {
    logger.error('❌ Error initializing invite cache:', err);
  }
}

async function registerSlashCommands(client) {
  try {
    const commands = Array.from(client.slashCommands.values())
      .filter(cmd => cmd?.data?.toJSON && typeof cmd.data.toJSON === 'function')
      .map(cmd => cmd.data.toJSON());

    if (!commands.length) return;
    if (!client.token || !client.application) return;

    await client.application.commands.set(commands);
    logger.success(`✅ Registered ${commands.length} global slash commands`);
  } catch (err) {
    logger.error('❌ Failed to register slash commands:', err);
  }
}

function startStatusRotation(client) {
  try {
    const statuses = config.status?.defaultStatuses || [];
    const interval = config.status?.interval || 30000;
    if (!statuses.length) return;

    let index = 0;

    const setStatus = () => {
      if (!client.user || !client.ws || client.ws.destroyed || client.ws.status !== 0) return;
      const status = statuses[index];

      try {
        client.user.setPresence({
          activities: [{ name: status.name, type: status.type }],
          status: config.status?.initialStatus || 'online'
        });
      } catch (err) {
        logger.warn(`⚠️ Status update failed: ${err.message}`);
      }
    };

    setTimeout(() => {
      setStatus();
      client.statusRotationInterval = setInterval(() => {
        index = (index + 1) % statuses.length;
        setStatus();
      }, interval);
    }, 5000);
  } catch (err) {
    logger.warn(`⚠️ Status rotation failed: ${err.message}`);
  }
}
