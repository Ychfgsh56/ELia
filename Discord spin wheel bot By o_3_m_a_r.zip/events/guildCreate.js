const { cachedInvites } = require('../lib/state');

module.exports = {
  name: 'guildCreate',
  once: false,
  async execute(guild) {
    try {
      global.logger?.info(`🆕 Joined guild: ${guild.name} (${guild.id})`);

      if (!guild?.invites) {
        global.logger?.warn(`⚠️ Cannot fetch invites from guild: ${guild?.name || 'Unknown'}`);
        return;
      }

      if (!guild.members.me?.permissions.has('ManageGuild')) {
        global.logger?.warn(`⚠️ Bot lacks ManageGuild permission in ${guild.name}, skipping invite cache`);
        return;
      }

      const invites = await guild.invites.fetch();
      cachedInvites.set(
        guild.id,
        new Map(invites.map(invite => [invite.code, invite.uses || 0]))
      );
    } catch (err) {
      global.errorHandler?.handleError(err, `guildCreate: ${guild?.name}`, {
        guildId: guild?.id,
        guildName: guild?.name
      });
    }
  }
};
