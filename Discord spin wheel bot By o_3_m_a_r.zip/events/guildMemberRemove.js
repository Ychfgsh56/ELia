// guildMemberRemove handler disabled — leaving does not remove inviter points per project rules.
module.exports = { name: 'guildMemberRemove', once: false, async execute() { return; } };
