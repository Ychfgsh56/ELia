const fs = require('fs');
const path = require('path');
const logger = require('../Utils/logger');

// 📦 تحميل الأوامر النصية (العادية) بشكل ديناميكي
const loadCommands = (client, baseDir) => {
  try {
    if (!client.commands) client.commands = new Map();
    if (!client.aliases) client.aliases = new Map();
    if (!client.categories) client.categories = new Map();

    // استخدم مجلد Commands من المستوى الأساسي
    const commandsDir = baseDir.endsWith('Commands') ? baseDir : path.join(baseDir, 'Commands');
    if (!fs.existsSync(commandsDir)) {
      logger.warn(`Commands folder not found: ${commandsDir}`, 'loadCommands');
      return;
    }

    const commandFiles = fs.readdirSync(commandsDir, { withFileTypes: true });
    // logger.info(`🔍 Loading commands from folder: ${commandsDir}`, 'loadCommands');

    for (const file of commandFiles) {
      const fullPath = path.join(commandsDir, file.name);

      // 📁 تحميل الأوامر من المجلدات الفرعية
      if (file.isDirectory()) {
        loadCommands(client, fullPath);
        continue;
      }

      // ✅ تحقق أن الملف JavaScript
      if (file.isFile() && file.name.endsWith('.js')) {
        try {
          delete require.cache[require.resolve(fullPath)];
          const commandModule = require(fullPath);
          
          // Skip null exports (deprecated files)
          if (!commandModule) {
            logger.debug(`تم تخطي ملف مطفأ: ${file.name}`, 'loadCommands');
            continue;
          }
          
          const commands = Array.isArray(commandModule) ? commandModule : [commandModule];

          for (const command of commands) {
            // ⚠️ تحقق من صلاحية الأمر
            if (!command || !command.name || (!command.execute && !command.run)) {
              logger.warn(`أمر غير صحيح في ${file.name}`, 'loadCommands');
              continue;
            }

            // 🛑 منع التكرار مع SlashCommands
            if (client.slashCommands && client.slashCommands.has(command.name)) {
              logger.warn(`تم تخطي أمر مكرر: ${command.name} (موجود في SlashCommands)`, 'loadCommands');
              continue;
            }

            // 🛑 منع التكرار مع الأوامر الأخرى
            if (client.commands.has(command.name)) {
              logger.warn(`أمر مكرر: ${command.name} من ${file.name}`, 'loadCommands');
              continue;
            }

            // ✅ إضافة الأمر
            client.commands.set(command.name, command);
            logger.debug(`تم تحميل الأمر: ${command.name}`, 'loadCommands');

            // 🔗 دعم الأسماء المستعارة (aliases)
            if (Array.isArray(command.aliases)) {
              command.aliases.forEach(alias => {
                if (client.aliases.has(alias)) {
                  logger.warn(`اسم مستعار مكرر: ${alias} للأمر ${command.name}`, 'loadCommands');
                } else {
                  client.aliases.set(alias, command.name);
                  logger.debug(`تم تحميل الاسم المستعار: ${alias}`, 'loadCommands');
                }
              });
            }

            // 🗂️ تصنيف الأوامر حسب الفئة
            if (command.category) {
              if (!client.categories.has(command.category)) {
                client.categories.set(command.category, []);
              }
              client.categories.get(command.category).push(command.name);
            }
          }
        } catch (error) {
          logger.error(error, `loadCommand-${file.name}`);
        }
      }
    }
  } catch (error) {
    logger.error(error, `loadCommands-directory`);
  }
};

// 📊 Display final statistics
const showCommandStats = (client) => {
  // logger.info(`📊 Total commands: ${client.commands.size}`, 'commandStats');
  // logger.info(`🔗 Total aliases: ${client.aliases.size}`, 'commandStats');

  // if (client.categories.size > 0) {
  //   client.categories.forEach((cmds, cat) => {
  //     logger.info(`📁 Category ${cat}: ${cmds.length} commands`, 'commandStats');
  //   });
  // }

  // logger.info('✅ All commands loaded successfully!', 'commandStats');
};

module.exports = { loadCommands, showCommandStats };
