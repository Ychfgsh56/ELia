const fs = require('fs');
const path = require('path');
const logger = require('../Utils/logger');

// دالة لتحميل أوامر Slash بشكل ديناميكي
const loadSlashCommands = (client, baseDir) => {
  try {
    // Load slash commands from root-level SlashCommands directory
    const slashCommandsDir = baseDir;
    if (!fs.existsSync(slashCommandsDir)) {
logger.warn(`Slash commands folder not found: ${slashCommandsDir}`, 'loadSlashCommands');
    return;
  }

  const commandFiles = fs.readdirSync(slashCommandsDir, { withFileTypes: true });
  // logger.info(`🔍 Loading slash commands from folder: ${slashCommandsDir}`, 'loadSlashCommands');

    for (const file of commandFiles) {
      const fullPath = path.join(slashCommandsDir, file.name);

      // تحميل الأوامر من المجلدات الفرعية
      if (file.isDirectory()) {
        loadSlashCommands(client, fullPath);
        continue;
      }

      // التحقق من أن الملف هو ملف JavaScript
      if (file.isFile() && file.name.endsWith('.js')) {
        try {
          // مسح الكاش لتحميل التعديلات الجديدة
          delete require.cache[require.resolve(fullPath)];

          const commandModule = require(fullPath);
          // دعم تصدير الأوامر كمصفوفة أو كائن واحد
          const commands = Array.isArray(commandModule) ? commandModule : [commandModule];

          for (const command of commands) {
            // التحقق من صحة الأمر
            if (!command.data || typeof command.data.toJSON !== 'function' || typeof command.execute !== 'function') {
              logger.warn(`أمر Slash غير صحيح في ${file.name}`, 'loadSlashCommands');
              continue;
            }

            // منع تكرار اسم الأمر
            if (client.slashCommands.has(command.data.name)) {
              logger.warn(`أمر Slash مكرر: ${command.data.name} من ${file.name}`, 'loadSlashCommands');
              continue;
            }

            // إضافة الأمر إلى مجموعة الأوامر
            client.slashCommands.set(command.data.name, command);
            logger.debug(`تم تحميل أمر Slash: ${command.data.name}`, 'loadSlashCommands');

            // تخزين دالة autocomplete إذا وجدت
            if (typeof command.autocomplete === 'function') {
              if (!client.slashAutocomplete) client.slashAutocomplete = new Map();
              client.slashAutocomplete.set(command.data.name, command.autocomplete);
              logger.debug(`تم تحميل autocomplete: ${command.data.name}`, 'loadSlashCommands');
            }

            // دعم الأسماء المستعارة (aliases) لأوامر Slash إذا وُجدت
            if (Array.isArray(command.aliases)) {
              command.aliases.forEach(alias => {
                if (client.slashCommands.has(alias)) {
                  logger.warn(`اسم مستعار مكرر: ${alias} لأمر Slash ${command.data.name}`, 'loadSlashCommands');
                } else {
                  client.slashCommands.set(alias, command);
                  logger.debug(`تم تحميل الاسم المستعار: ${alias}`, 'loadSlashCommands');
                }
              });
            }

            // تصنيف الأوامر حسب الفئة إذا وُجدت
            if (command.category) {
              if (!client.categories) client.categories = new Map();
              if (!client.categories.has(command.category)) {
                client.categories.set(command.category, []);
              }
              client.categories.get(command.category).push(command.data.name);
              logger.debug(`تم تصنيف: ${command.data.name} في ${command.category}`, 'loadSlashCommands');
            }
          }
        } catch (error) {
          logger.error(error, `loadSlashCommand-${file.name}`);
        }
      }
    }
  } catch (error) {
    logger.error(error, `loadSlashCommands-directory`);
  }
};

module.exports = { loadSlashCommands };