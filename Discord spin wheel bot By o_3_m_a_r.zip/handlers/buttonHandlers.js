/**
 * Button Handlers for Spin Game
 */

const { MessageFlags } = require('discord.js');
const { ContainerBuilder } = require('../Utils/container');
const logger = require('../Utils/logger');
const { chooseWinner } = require('../lib/selection');
const { generateWheelPNG } = require('../lib/wheel');

async function handleSpinInteraction(deps) {

  const {
    interaction,
    getUserInvites,
    getServerConfig,
    getPrizes,
    updateUserInvites
  } = deps;

  try {

    // مهم جدًا حتى لا يفشل التفاعل
    if (!interaction.deferred && !interaction.replied) {
      await interaction.deferReply();
    }

    const config = await getServerConfig(interaction.guild.id);
    const userInvites = await getUserInvites(interaction.user.id, interaction.guild.id);

    let spinType = null;
    let cost = 0;

    if (interaction.customId === 'normal_spin') {
      spinType = 'normal';
      cost = config.normalSpinCost;
    } else if (interaction.customId === 'special_spin') {
      spinType = 'special';
      cost = config.specialSpinCost;
    } else {
      return interaction.editReply({ content: 'نوع عجلة غير معروف.' });
    }

    if (userInvites < cost) {
      return interaction.editReply({
        content: `تحتاج ${cost} نقاط`
      });
    }

    const prizes = await getPrizes(interaction.guild.id, spinType);

    if (!prizes || prizes.length === 0) {
      return interaction.editReply({
        content: 'لا توجد جوائز محددة.'
      });
    }

    const players = prizes.map((p, i) => ({
      userId: `prize_${i}`,
      username: String(p.value),
      avatarURL: '',
      weight: p.weight ?? 0
    }));

    let pick = chooseWinner(players);

    if (!pick) {
      const winnerIndex = Math.floor(Math.random() * players.length);
      pick = {
        winnerIndex,
        winner: players[winnerIndex]
      };
    }

    const newPoints = Math.max(0, userInvites - cost);

    await updateUserInvites(
      interaction.user.id,
      interaction.guild.id,
      newPoints
    );

    const theme = config?.wheelTheme || 'bw';

    // توليد صورة العجلة
    const pngBuffer = await generateWheelPNG({
      players,
      winnerIndex: pick.winnerIndex,
      botAvatar: interaction.client.user.displayAvatarURL({
        extension: 'png',
        size: 256
      }),
      theme
    });

    await interaction.editReply({
      content: 'جاري تدوير العجلة...',
      files: [{
        attachment: pngBuffer,
        name: 'wheel.png'
      }]
    });

    await interaction.followUp({
      content: `الجائزة : ${pick.winner.username}\nالفائز : <@${interaction.user.id}>`
    });

    // ===== اللوق =====

    try {

      if (config?.spinLogChannelId) {

        const logChannel = await interaction.guild.channels
          .fetch(config.spinLogChannelId)
          .catch(() => null);

        if (logChannel) {

          const logContainer = new ContainerBuilder()

            .addTextDisplayComponents(t =>
              t.setContent('دوران عجلة')
            )

            .addSeparatorComponents(s =>
              s.setSpacing(1)
            )

            .addTextDisplayComponents(t =>
              t.setContent(
`العضو : <@${interaction.user.id}>
نوع العجلة : ${spinType === 'normal' ? 'عادية' : 'خاصة'}
الجائزة : ${pick.winner.username}
الفائز : <@${interaction.user.id}>
النقاط بعد الخصم : ${newPoints}`
              )
            );

          await logChannel.send({
            ...logContainer.build(),
            flags: [MessageFlags.IsComponentsV2]
          }).catch(() => {});

        }

      }

    } catch (logErr) {
      console.error('Spin log error:', logErr);
    }

  } catch (err) {

    console.error('Spin interaction error:', err);

    try {
      await interaction.editReply({
        content: 'حدث خطأ أثناء تنفيذ الدور.'
      });
    } catch {}

  }

}

module.exports = { handleSpinInteraction };