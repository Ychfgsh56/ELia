/**
 * BlackDev Project
 * Developer: o_3_m_a_r
 * YouTube: https://www.youtube.com/@BlackDev_0
 * Discord: https://discord.com/invite/mQAWTNrcNQ
 * Copyright © o_3_m_a_r. All Rights Reserved.
 *
 * Main bot startup.
 */

const { Client, Collection, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { loadCommands } = require('../handlers/loadCommands');
const { loadSlashCommands } = require('../handlers/loadSlashCommands');
const logger = require('../Utils/logger');
const config = require('../config');

async function startBot(token) {
  return new Promise((resolve, reject) => {
    const intents = [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.MessageContent
    ];

    const statuses = config.status?.defaultStatuses || [{ name: '/help', type: 0 }];
    const firstStatus = statuses[0];

    const client = new Client({
      intents,
      partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'USER'],
      presence: {
        activities: [{ name: firstStatus.name || '/help', type: firstStatus.type || 0 }],
        status: config.status?.initialStatus || 'online'
      }
    });

    client.setMaxListeners(50);
    client.meta = {
      startTime: Date.now(),
      index: 0,
      status: 'starting',
      botName: 'Unknown'
    };
    client.startTime = client.meta.startTime;

    client.commandCooldowns = new Map();
    client.commands = new Collection();
    client.slashCommands = new Collection();
    client.aliases = new Collection();
    client.categories = new Collection();
    client.cooldowns = new Collection();
    client.interactions = new Collection();

    try {
      const commandsPath = path.join(__dirname, '../Commands');
      const slashCommandsPath = path.join(__dirname, '../SlashCommands');
      const eventsPath = path.join(__dirname, '../events');

      if (fs.existsSync(commandsPath)) {
        loadCommands(client, commandsPath);
        logger.info(`✅ Loaded ${client.commands.size} basic commands`);
      }

      if (fs.existsSync(slashCommandsPath)) {
        loadSlashCommands(client, slashCommandsPath);
        logger.info(`✅ Loaded ${client.slashCommands.size} slash commands`);
      }

      if (fs.existsSync(eventsPath)) {
        const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

        for (const file of eventFiles) {
          const filePath = path.join(eventsPath, file);
          try {
            delete require.cache[require.resolve(filePath)];
            const event = require(filePath);

            if (typeof event === 'function') {
              event(client);
            } else if (event?.name && typeof event.execute === 'function') {
              const emitter = event.once ? client.once.bind(client) : client.on.bind(client);
              emitter(event.name, (...args) => event.execute(...args, client));
            }
          } catch (error) {
            logger.error(`Event load failed: ${file}`, error);
          }
        }
      }
    } catch (error) {
      logger.error('❌ Main bot initialization failed:', error);
      return reject(error);
    }

    client.on('error', error => {
      logger.error('❌ Main bot error:', error);
      client.meta.lastError = { time: Date.now(), message: error.message };
    });

    client.on('warn', warning => logger.warn(`⚠️ Main bot warning: ${warning}`));

    client.once('ready', async () => {
      try {
        if (!client.user) throw new Error('Client user missing after ready');

        client.meta.botName = client.user.tag;
        client.meta.status = 'online';
        client.meta.readyTime = Date.now();
        client.meta.guilds = client.guilds.cache.size;
        client.meta.users = client.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);

        logger.success(
          `🚀 Main bot ready: ${client.user.tag} | ${client.meta.guilds} servers | ${client.meta.users} users`
        );

        resolve(client);
      } catch (error) {
        logger.error('❌ Ready event failed:', error);
        reject(error);
      }
    });

    const loginTimeout = setTimeout(() => {
      reject(new Error('❌ Login timeout after 30 seconds'));
      client.destroy().catch(() => {});
    }, 30000);

    client.login(token)
      .then(() => clearTimeout(loginTimeout))
      .catch(error => {
        clearTimeout(loginTimeout);
        logger.error('❌ Main bot login failed:', error);
        client.destroy().catch(() => {});
        reject(error);
      });
  });
}

module.exports = startBot;
