const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addprize')
    .setDescription('إضافة أو تحديث جائزة')
    .addStringOption(option => 
      option.setName('type')
        .setDescription('نوع الدور')
        .setRequired(true)
        .addChoices({ name: 'عادي', value: 'normal' }, { name: 'خاص', value: 'special' })
    )
    .addStringOption(option => option.setName('prize').setDescription('اسم الجائزة').setRequired(true))
    .addIntegerOption(option => option.setName('weight').setDescription('نسبه الجائزة').setRequired(true)),

  async execute(interaction) {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ 
          content: 'تحتاج لصلاحيات المدير لاستخدام هذا الأمر.', 
          ephemeral: true 
        });
      }

      const type = interaction.options.getString('type');
      const prize = interaction.options.getString('prize');
      const weight = interaction.options.getInteger('weight');

      await db.addOrUpdatePrize(interaction.guild.id, type, prize, weight);

      // Reply only to the command user (ephemeral)
      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('تم حفظ الجائزة'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t => t.setContent(`تم إضافة/تحديث الجائزة "${prize}" لنوع ${type} بالنسبه ${weight}.`));
      const built = container.build();
      await interaction.reply({ ...built, flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

      // Also send a log message to the configured spin log channel (if any)
      try {
        const cfg = await db.getServerConfig(interaction.guild.id);
        if (cfg && cfg.spinLogChannelId) {
          const logChannel = await interaction.guild.client.channels.fetch(cfg.spinLogChannelId).catch(() => null);
          if (logChannel) {
            const { ContainerBuilder: C } = require('../Utils/container');
            const { MessageFlags: MF } = require('discord.js');
            const logContainer = new C();
            logContainer.addTextDisplayComponents(t => t.setContent('🟢 جائزة مضافة/محدّثة'));
            logContainer.addSeparatorComponents(s => s.setSpacing(1));
            logContainer.addTextDisplayComponents(t => t.setContent(`المشغّل: ${interaction.user.tag} (${interaction.user.id})\nالجائزة: "${prize}"\nالنوع: ${type}\nالنسبه: ${weight}`));
            await logChannel.send({ ...logContainer.build(), flags: [MF.IsComponentsV2] }).catch(() => {});
          }
        }
      } catch (e) {
        console.error('Failed to send prize log:', e);
      }
    } catch (error) {
      console.error('❌ Error in /addprize command:', error);
      return interaction.reply({ 
        content: '❌ An error occurred while processing the command.', 
        ephemeral: true 
      });
    }
  }
};
