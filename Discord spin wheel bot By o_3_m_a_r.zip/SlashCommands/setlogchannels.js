const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogchannels')
    .setDescription('تعيين قنوات سجل الدعوات والعجلة')
    .addChannelOption(option =>
      option
        .setName('invitelog')
        .setDescription('قناة سجل الدعوات')
        .setRequired(true)
    )
    .addChannelOption(option =>
      option
        .setName('spinlog')
        .setDescription('قناة سجل العجلة')
        .setRequired(true)
    ),

  async execute(interaction) {
    try {

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: 'هذا الأمر للمدير فقط.',
          ephemeral: true
        });
      }

      const inviteLogChannel = interaction.options.getChannel('invitelog');
      const spinLogChannel = interaction.options.getChannel('spinlog');

      await db.setServerConfig(
        interaction.guild.id,
        inviteLogChannel.id,
        spinLogChannel.id
      );

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('تم تعيين القنوات')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(
`الدعوات : ${inviteLogChannel}
العجلة : ${spinLogChannel}`
          )
        );

      await interaction.reply({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

      // ===== إرسال لوق =====

      try {

        const logContainer = new ContainerBuilder()

          .addTextDisplayComponents(t =>
            t.setContent('تعيين القنوات')
          )

          .addSeparatorComponents(s =>
            s.setSpacing(1)
          )

          .addTextDisplayComponents(t =>
            t.setContent(
`الدعوات : ${inviteLogChannel}
العجلة : ${spinLogChannel}
بواسطة : <@${interaction.user.id}>`
            )
          );

        await spinLogChannel.send({
          ...logContainer.build(),
          flags: [MessageFlags.IsComponentsV2]
        }).catch(() => {});

      } catch (logErr) {
        console.error('Failed to send log:', logErr);
      }

    } catch (error) {

      console.error('Error in setlogchannels command:', error);

      if (!interaction.replied) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }

    }
  }
};