const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reset')
    .setDescription('إعادة ضبط النقاط')
    .addStringOption(option =>
      option
        .setName('target')
        .setDescription('إعادة الضبط للجميع أو لمستخدم')
        .setRequired(true)
        .addChoices(
          { name: 'الكل', value: 'all' },
          { name: 'مستخدم', value: 'user' }
        )
    )
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('المستخدم')
    ),

  async execute(interaction) {
    try {

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: 'هذا الأمر للمدير فقط.',
          ephemeral: true
        });
      }

      const target = interaction.options.getString('target');

      // ===== reset all =====

      if (target === 'all') {

        await db.resetAllUserInvites(
          interaction.guild.id
        );

        const container = new ContainerBuilder()

          .addTextDisplayComponents(t =>
            t.setContent('تمت إعادة الضبط')
          )

          .addSeparatorComponents(s =>
            s.setSpacing(1)
          )

          .addTextDisplayComponents(t =>
            t.setContent('جميع النقاط تم تصفيرها')
          );

        return interaction.reply({
          ...container.build(),
          flags: [MessageFlags.IsComponentsV2]
        });

      }

      // ===== reset user =====

      const user = interaction.options.getUser('user');

      if (!user) {
        return interaction.reply({
          content: 'حدد المستخدم.',
          ephemeral: true
        });
      }

      await db.resetUserInvites(
        user.id,
        interaction.guild.id
      );

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('تمت إعادة الضبط')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(`${user.tag} : 0`)
        );

      return interaction.reply({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (error) {

      console.error('Error in reset command:', error);

      if (!interaction.replied) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }

    }
  }
};