const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { ContainerBuilder, ButtonBuilder, ButtonStyle } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('عرض المساعدة'),

  async execute(interaction) {
    try {
      const container = new ContainerBuilder()
        .addTextDisplayComponents(t =>
          t.setContent('اختر أحد الأزرار لعرض الشرح أو الأوامر')
        )
        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )
        .addActionRowComponents(r =>
          r.setComponents(
            new ButtonBuilder()
              .setCustomId('help_explain')
              .setLabel('شرح النظام')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('help_commands')
              .setLabel('الأوامر')
              .setStyle(ButtonStyle.Secondary),
            // ✅ زر الرابط - بدون customId
            new ButtonBuilder()
              .setLabel('سياسة الخصوصية')
              .setStyle(ButtonStyle.Link)
              .setURL('https://docs.google.com/your-policy-link') // ضع رابطك الحقيقي
          )
        );

      await interaction.reply({
        ...container.build(),
        flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2]
      });
    } catch (err) {
      console.error('Error in help command:', err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }
    }
  }
};