const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setinviteage')
    .setDescription('ضبط الحد الأدنى لعمر الحساب')
    .addIntegerOption(opt =>
      opt
        .setName('months')
        .setDescription('الحد الأدنى لعمر الحساب بالشهور')
        .setRequired(true)
        .addChoices(
          { name: '1 شهر', value: 1 },
          { name: '2 شهر', value: 2 },
          { name: '3 شهر', value: 3 },
          { name: '4 شهر', value: 4 },
          { name: '5 شهر', value: 5 },
          { name: '6 شهر', value: 6 },
          { name: '7 شهر', value: 7 }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    try {

      const months = interaction.options.getInteger('months');
      const guildId = interaction.guild.id;

      const ok = await db.setMinAccountAge(
        guildId,
        months
      );

      if (!ok) {
        return interaction.reply({
          content: 'فشل حفظ الإعداد.',
          ephemeral: true
        });
      }

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('تم ضبط عمر الحساب')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(`الحد الأدنى : ${months} شهر`)
        );

      await interaction.reply({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (err) {

      console.error('Error in setinviteage command:', err);

      if (!interaction.replied) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }

    }
  }
};