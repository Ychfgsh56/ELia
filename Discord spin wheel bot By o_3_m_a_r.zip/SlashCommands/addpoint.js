const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addpoint')
    .setDescription('إضافة نقاط لمستخدم')
    .addUserOption(option => option.setName('user').setDescription('المستخدم المراد إضافة نقاط له').setRequired(true))
    .addIntegerOption(option => option.setName('points').setDescription('عدد النقاط المراد إضافتها').setRequired(true)),

  async execute(interaction) {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ 
          content: 'تحتاج لصلاحيات المدير لاستخدام هذا الأمر.', 
          ephemeral: true 
        });
      }

      const user = interaction.options.getUser('user');
      const pointsToAdd = interaction.options.getInteger('points');

      if (!user || isNaN(pointsToAdd) || pointsToAdd <= 0) {
        return interaction.reply({ 
          content: 'استخدام غير صحيح. المثال: `/addpoint user:@user points:عدد`', 
          ephemeral: true 
        });
      }

      const currentInvites = await db.getUserInvites(user.id, interaction.guild.id);
      const newInvites = currentInvites + pointsToAdd;
      await db.updateUserInvites(user.id, interaction.guild.id, newInvites);

      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('تمت إضافة نقاط'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t => t.setContent(`تمت إضافة ${pointsToAdd} نقطة للمستخدم ${user.tag}.\nالمجموع الآن: ${newInvites} نقطة.`));
      const built = container.build();
      return interaction.reply({ ...built, flags: [MessageFlags.IsComponentsV2] });
    } catch (error) {
      console.error('❌ Error in /addpoint command:', error);
      return interaction.reply({ 
        content: '❌ An error occurred while processing the command.', 
        ephemeral: true 
      });
    }
  }
};
