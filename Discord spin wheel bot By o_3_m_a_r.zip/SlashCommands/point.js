const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('point')
    .setDescription('عرض نقاط الدعوات')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('المستخدم')
    ),

  async execute(interaction) {
    try {

      const user = interaction.options.getUser('user') || interaction.user;

      const points = await db.getUserInvites(
        user.id,
        interaction.guild.id
      );

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('نقاط الدعوات')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(`${user.tag} : ${points}`)
        );

      await interaction.reply({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (error) {

      console.error('Error in point command:', error);

      if (!interaction.replied) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }

    }
  }
};