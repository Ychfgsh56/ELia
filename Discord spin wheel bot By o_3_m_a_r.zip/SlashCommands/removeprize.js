const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removeprize')
    .setDescription('حذف جائزة')
    .addStringOption(option => 
      option.setName('type')
        .setDescription('نوع الدور')
        .setRequired(true)
        .addChoices({ name: 'عادي', value: 'normal' }, { name: 'خاص', value: 'special' })
    )
    .addStringOption(option => 
      option.setName('prize')
        .setDescription('اسم الجائزة')
        .setRequired(true)
        .setAutocomplete(true)
    ),

  async execute(interaction) {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ 
          content: 'تحتاج لصلاحيات المدير لاستخدام هذا الأمر.', 
          ephemeral: true 
        });
      }

      const type = interaction.options.getString('type');
      const prize = interaction.options.getString('prize');

      const removed = await db.removePrize(interaction.guild.id, type, prize);

      if (removed) {
        const container = new ContainerBuilder()
          .addTextDisplayComponents(t => t.setContent('تم حذف الجائزة'))
          .addSeparatorComponents(s => s.setSpacing(1))
          .addTextDisplayComponents(t => t.setContent(`تم حذف الجائزة "${prize}" من نوع ${type}.`));
        const built = container.build();
        await interaction.reply({ ...built, flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

        // send log to spin log channel if configured
        try {
          const cfg = await db.getServerConfig(interaction.guild.id);
          if (cfg && cfg.spinLogChannelId) {
            const logChannel = await interaction.guild.client.channels.fetch(cfg.spinLogChannelId).catch(() => null);
            if (logChannel) {
              const { ContainerBuilder: C } = require('../Utils/container');
              const { MessageFlags: MF } = require('discord.js');
              const logContainer = new C();
              logContainer.addTextDisplayComponents(t => t.setContent('🔴 جائزة محذوفة'));
              logContainer.addSeparatorComponents(s => s.setSpacing(1));
              logContainer.addTextDisplayComponents(t => t.setContent(`المشغّل: ${interaction.user.tag} (${interaction.user.id})\nالجائزة: "${prize}"\nالنوع: ${type}`));
              await logChannel.send({ ...logContainer.build(), flags: [MF.IsComponentsV2] }).catch(() => {});
            }
          }
        } catch (e) {
          console.error('Failed to send remove prize log:', e);
        }
        return;
      } else {
        return interaction.reply({ 
          content: `لم يتم العثور على الجائزة "${prize}" من نوع ${type}.`, 
          ephemeral: true 
        });
      }
    } catch (error) {
      console.error('❌ Error in /removeprize command:', error);
      return interaction.reply({ 
        content: '❌ An error occurred while processing the command.', 
        ephemeral: true 
      });
    }
  }
};
