const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removepoint')
    .setDescription('إزالة نقاط من مستخدم')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('المستخدم')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName('points')
        .setDescription('عدد النقاط')
        .setRequired(true)
    ),

  async execute(interaction) {
    try {

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: 'هذا الأمر للمدير فقط.',
          ephemeral: true
        });
      }

      const user = interaction.options.getUser('user');
      const points = interaction.options.getInteger('points');

      if (!points || points <= 0) {
        return interaction.reply({
          content: 'عدد النقاط غير صحيح.',
          ephemeral: true
        });
      }

      const current = await db.getUserInvites(user.id, interaction.guild.id);
      const newPoints = Math.max(0, current - points);

      await db.updateUserInvites(
        user.id,
        interaction.guild.id,
        newPoints
      );

      // رسالة الأمر
      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('تمت إزالة النقاط'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t => t.setContent(`${user.tag} : ${newPoints}`));

      await interaction.reply({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

      // ===== إرسال اللوق =====

      try {

        const config = await db.getServerConfig(interaction.guild.id);

        if (config?.spinLogChannelId) {

          const logChannel = await interaction.guild.channels
            .fetch(config.spinLogChannelId)
            .catch(() => null);

          if (logChannel) {

            const logContainer = new ContainerBuilder()

              .addTextDisplayComponents(t =>
                t.setContent('إزالة نقاط')
              )

              .addSeparatorComponents(s =>
                s.setSpacing(1)
              )

              .addTextDisplayComponents(t =>
                t.setContent(
`العضو : <@${user.id}>
النقاط المزالة : ${points}
النقاط بعد الخصم : ${newPoints}
بواسطة : <@${interaction.user.id}>`
                )
              );

            await logChannel.send({
              ...logContainer.build(),
              flags: [MessageFlags.IsComponentsV2]
            }).catch(() => {});

          }

        }

      } catch (logErr) {
        console.error('Failed to send removepoint log:', logErr);
      }

    } catch (err) {

      console.error('Error in removepoint command:', err);

      if (!interaction.replied) {
        return interaction.reply({
          content: 'حدث خطأ.',
          ephemeral: true
        });
      }

    }
  }
};