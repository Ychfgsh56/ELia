const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('prizes')
    .setDescription('عرض الجوائز لنوع الدور المحدد')
    .addStringOption(option => 
      option.setName('type')
        .setDescription('نوع الدور')
        .setRequired(true)
        .addChoices({ name: 'عادي', value: 'normal' }, { name: 'خاص', value: 'special' })
    ),

  async execute(interaction) {
    try {
      const type = interaction.options.getString('type');
      const prizes = await db.getPrizes(interaction.guild.id, type);

      if (prizes.length === 0) {
        return interaction.reply({ 
          content: `لا توجد جوائز لهذا النوع.`, 
          ephemeral: true 
        });
      }

      const prizeList = prizes.map(p => `${p.value} (النسبه: ${p.weight})`).join('\n');

      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('الجوائز لنوع الدور'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t => t.setContent(prizeList));
      const built = container.build();
      return interaction.reply({ ...built, flags: [MessageFlags.IsComponentsV2] });
    } catch (error) {
      console.error('❌ Error in /prizes command:', error);
      return interaction.reply({ 
        content: '❌ An error occurred while processing the command.', 
        ephemeral: true 
      });
    }
  }
};
