const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const { setWheelTheme, getServerConfig } = require('../Utils/database');

module.exports = {

  data: new SlashCommandBuilder()
    .setName('wheel-style')
    .setDescription('تغيير ألوان العجلة')
    .addStringOption(option =>
      option
        .setName('style')
        .setDescription('اختر ستايل العجلة')
        .setRequired(true)
        .addChoices(
        { name: 'Random', value: 'random' },

        { name: 'Black White', value: 'bw' },
        { name: 'Red Black', value: 'rb' },
        { name: 'Gold Black', value: 'gold' },
        { name: 'Purple Black', value: 'purple' },
        { name: 'Blue Black', value: 'blue' },
        { name: 'Emerald Black', value: 'emerald' },

        { name: 'Fire', value: 'fire' },
        { name: 'Ice', value: 'ice' },
        { name: 'Neon', value: 'neon' }
        )
    ),

  async execute(interaction) {

    // فقط المشرفين يمكنهم تغيير ستايل العجلة
    if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: '❌ تحتاج صلاحية مشرف لتغيير ستايل العجلة.',
        ephemeral: true
      });
    }

    const style = interaction.options.getString('style');

    try {
      await setWheelTheme(interaction.guild.id, style);

      const updated = await getServerConfig(interaction.guild.id);
      const stored = updated?.wheelTheme || 'غير مخزّن بعد';

      await interaction.reply({
        content: `تم تغيير ستايل العجلة إلى : ${style}\n(القيمة المخزنة: ${stored})`,
        ephemeral: true
      });
    } catch (err) {
      console.error('Failed to update wheel style:', err);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء حفظ ستايل العجلة. حاول مرة أخرى.',
        ephemeral: true
      });
    }

  }

};