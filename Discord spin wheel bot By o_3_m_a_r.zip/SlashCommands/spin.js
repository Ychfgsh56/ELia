const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder, ButtonBuilder, ButtonStyle, containerToV2FullPayload } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('spin')
    .setDescription('فتح واجهة العجلة'),

  async execute(interaction) {
    try {

      const config = await db.getServerConfig(interaction.guild.id);
      const userInvites = await db.getUserInvites(interaction.user.id, interaction.guild.id);

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('اختر نوع العجلة')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(
`عادية : ${config.normalSpinCost} نقاط
خاصة : ${config.specialSpinCost} نقاط

نقاطك : ${userInvites}`
          )
        )

        .addSeparatorComponents(s => s.setSpacing(1))

        .addActionRowComponents(r =>
          r.setComponents(

            new ButtonBuilder()
              .setCustomId('normal_spin')
              .setLabel('عجلة عادية')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(userInvites < config.normalSpinCost),

            new ButtonBuilder()
              .setCustomId('special_spin')
              .setLabel('عجلة خاصة')
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(userInvites < config.specialSpinCost)

          )
        );

      const built = container.build();

      return interaction.reply({
        ...containerToV2FullPayload(built),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (error) {
      console.error(error);
      return interaction.reply({ content: 'حدث خطأ.', ephemeral: true });
    }
  }
};