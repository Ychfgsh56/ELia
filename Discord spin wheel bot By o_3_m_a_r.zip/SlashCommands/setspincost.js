const { SlashCommandBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setspincost')
    .setDescription('ضبط تكلفة دورات اللفّة (نقاط)')
    .addIntegerOption(option => option.setName('normal').setDescription('تكلفة الدور العادي (نقاط)').setRequired(true))
    .addIntegerOption(option => option.setName('special').setDescription('تكلفة الدور الخاص (نقاط)').setRequired(true)),

  async execute(interaction) {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ 
          content: 'تحتاج لصلاحيات المدير لاستخدام هذا الأمر.', 
          ephemeral: true 
        });
      }

      const normalCost = interaction.options.getInteger('normal');
      const specialCost = interaction.options.getInteger('special');

      await db.setSpinCosts(interaction.guild.id, normalCost, specialCost);

      const text = `تم ضبط التكلفة\n\nتم ضبط تكلفة الدور العادي إلى ${normalCost} نقاط\nتم ضبط تكلفة الدور الخاص إلى ${specialCost} نقاط`;
      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('تم ضبط التكلفة'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t => t.setContent(text));
      const built = container.build();
      return interaction.reply({ ...built, flags: [MessageFlags.IsComponentsV2] });
    } catch (error) {
      console.error('Error in /setspincost command:', error);
      return interaction.reply({ 
        content: 'حدث خطأ أثناء تنفيذ الأمر.', 
        ephemeral: true 
      });
    }
  }
};
