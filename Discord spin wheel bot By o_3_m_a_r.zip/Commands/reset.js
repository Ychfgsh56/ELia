const { PermissionsBitField, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  name: 'reset',
  description: 'إعادة ضبط النقاط للسيرفر أو مستخدم',
  usage: '-reset <all|user> [@user]',

  async execute(message, args) {
    try {

      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply({ content: 'هذا الأمر للمدير فقط.' });
      }

      const target = args[0];

      // reset all
      if (target === 'all') {

        await db.resetAllUserInvites(message.guild.id);

        const container = new ContainerBuilder()
          .addTextDisplayComponents(t => t.setContent('تمت إعادة الضبط'))
          .addSeparatorComponents(s => s.setSpacing(1))
          .addTextDisplayComponents(t =>
            t.setContent('جميع النقاط تم تصفيرها')
          );

        await message.channel.send({
          ...container.build(),
          flags: [MessageFlags.IsComponentsV2]
        });

        // log
        try {

          const config = await db.getServerConfig(message.guild.id);

          if (config?.spinLogChannelId) {

            const logChannel = await message.guild.channels
              .fetch(config.spinLogChannelId)
              .catch(() => null);

            if (logChannel) {

              const logContainer = new ContainerBuilder()
                .addTextDisplayComponents(t => t.setContent('إعادة ضبط'))
                .addSeparatorComponents(s => s.setSpacing(1))
                .addTextDisplayComponents(t =>
                  t.setContent(
`النوع : جميع النقاط
بواسطة : <@${message.author.id}>`
                  )
                );

              await logChannel.send({
                ...logContainer.build(),
                flags: [MessageFlags.IsComponentsV2]
              }).catch(() => {});

            }

          }

        } catch (err) {
          console.error('Failed to send reset log:', err);
        }

        return;
      }

      // reset user
      const user = message.mentions.users.first();

      if (!user) {
        return message.reply({
          content: 'الاستخدام: -reset all أو -reset user @user'
        });
      }

      await db.resetUserInvites(user.id, message.guild.id);

      const container = new ContainerBuilder()
        .addTextDisplayComponents(t => t.setContent('تمت إعادة الضبط'))
        .addSeparatorComponents(s => s.setSpacing(1))
        .addTextDisplayComponents(t =>
          t.setContent(`${user.tag} : 0`)
        );

      await message.channel.send({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

      // log
      try {

        const config = await db.getServerConfig(message.guild.id);

        if (config?.spinLogChannelId) {

          const logChannel = await message.guild.channels
            .fetch(config.spinLogChannelId)
            .catch(() => null);

          if (logChannel) {

            const logContainer = new ContainerBuilder()
              .addTextDisplayComponents(t => t.setContent('إعادة ضبط'))
              .addSeparatorComponents(s => s.setSpacing(1))
              .addTextDisplayComponents(t =>
                t.setContent(
`العضو : <@${user.id}>
النقاط : 0
بواسطة : <@${message.author.id}>`
                )
              );

            await logChannel.send({
              ...logContainer.build(),
              flags: [MessageFlags.IsComponentsV2]
            }).catch(() => {});

          }

        }

      } catch (err) {
        console.error('Failed to send reset log:', err);
      }

    } catch (error) {

      console.error('Error in reset command:', error);

      return message.reply({
        content: 'حدث خطأ.'
      });

    }
  }
};