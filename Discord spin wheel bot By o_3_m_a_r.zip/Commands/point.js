const { MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  name: 'point',
  aliases: ['points'],
  description: 'عرض نقاط الدعوات',
  usage: '-point [@user]',

  async execute(message) {
    try {
      const user = message.mentions.users.first() || message.author;

      const invites = await db.getUserInvites(
        user.id,
        message.guild.id
      );

      const container = new ContainerBuilder()
        .addTextDisplayComponents(t =>
          t.setContent('نقاط الدعوات')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(`${user.tag} : ${invites}`)
        );

      const built = container.build();

      await message.channel.send({
        ...built,
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (error) {

      console.error('Error in point command:', error);

      return message.reply({
        content: 'حدث خطأ.'
      });

    }
  }
};