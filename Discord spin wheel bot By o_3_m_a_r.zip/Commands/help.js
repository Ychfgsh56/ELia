const { MessageFlags } = require('discord.js');
const { ContainerBuilder, ButtonBuilder, ButtonStyle } = require('../Utils/container');

module.exports = {
  name: 'help',
  aliases: ['commands'],
  description: 'عرض المساعدة',

  async execute(message) {
    try {

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('اختر أحد الأزرار لعرض الشرح أو الأوامر')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addActionRowComponents(r =>
          r.setComponents(

            new ButtonBuilder()
              .setCustomId('help_explain')
              .setLabel('شرح النظام')
              .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
              .setCustomId('help_commands')
              .setLabel('الأوامر')
              .setStyle(ButtonStyle.Secondary)

          )
        );

      await message.channel.send({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (err) {

      console.error('Error in help command:', err);

      try {
        await message.channel.send('حدث خطأ.');
      } catch {}

    }
  }
};