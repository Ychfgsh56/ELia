const { PermissionsBitField, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  name: 'addpoint',
  aliases: ['point-add', 'pointadd', 'add-point'],
  description: 'إضافة نقاط لمستخدم',
  usage: '-addpoint @user <points>',

  async execute(message, args) {
    try {

      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply({ content: 'هذا الأمر للمدير فقط.' });
      }

      const user = message.mentions.users.first();
      const pointsToAdd = parseInt(args[1]);

      if (!user || isNaN(pointsToAdd) || pointsToAdd <= 0) {
        return message.reply({ content: 'الاستخدام: -addpoint @user <points>' });
      }

      const currentInvites = await db.getUserInvites(
        user.id,
        message.guild.id
      );

      const newInvites = currentInvites + pointsToAdd;

      await db.updateUserInvites(
        user.id,
        message.guild.id,
        newInvites
      );

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('تمت إضافة نقاط')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(
`${user.tag} : +${pointsToAdd}
المجموع : ${newInvites}`
          )
        );

      const built = container.build();

      await message.channel.send({
        ...built,
        flags: [MessageFlags.IsComponentsV2]
      });

      // log
      try {

        const config = await db.getServerConfig(message.guild.id);

        if (config?.spinLogChannelId) {

          const logChannel = await message.guild.channels
            .fetch(config.spinLogChannelId)
            .catch(() => null);

          if (logChannel) {

            const logContainer = new ContainerBuilder()

              .addTextDisplayComponents(t =>
                t.setContent('إضافة نقاط')
              )

              .addSeparatorComponents(s =>
                s.setSpacing(1)
              )

              .addTextDisplayComponents(t =>
                t.setContent(
`العضو : <@${user.id}>
النقاط : +${pointsToAdd}
المجموع : ${newInvites}
بواسطة : <@${message.author.id}>`
                )
              );

            await logChannel.send({
              ...logContainer.build(),
              flags: [MessageFlags.IsComponentsV2]
            }).catch(() => {});

          }

        }

      } catch (logErr) {
        console.error('Failed to send log:', logErr);
      }

    } catch (error) {

      console.error('Error in addpoint command:', error);

      return message.reply({
        content: 'حدث خطأ.'
      });

    }
  }
};