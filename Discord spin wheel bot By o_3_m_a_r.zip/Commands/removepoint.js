const { PermissionsBitField, MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder } = require('../Utils/container');

module.exports = {
  name: 'removepoint',
  aliases: ['point-remove', 'pointremove', 'remove-point'],
  description: 'إزالة نقاط من مستخدم',
  usage: '-removepoint @user <points>',

  async execute(message, args) {
    try {

      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply({ content: 'هذا الأمر للمدير فقط.' });
      }

      const user = message.mentions.users.first();
      const points = parseInt(args[1]);

      if (!user || !points || points <= 0) {
        return message.reply({
          content: 'الاستخدام: -removepoint @user <points>'
        });
      }

      const current = await db.getUserInvites(
        user.id,
        message.guild.id
      );

      const newPoints = Math.max(
        0,
        current - points
      );

      await db.updateUserInvites(
        user.id,
        message.guild.id,
        newPoints
      );

      // رسالة القناة
      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('تمت إزالة النقاط')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(`${user.tag} : ${newPoints}`)
        );

      await message.channel.send({
        ...container.build(),
        flags: [MessageFlags.IsComponentsV2]
      });

      // ===== إرسال اللوق =====

      try {

        const config = await db.getServerConfig(
          message.guild.id
        );

        if (config?.spinLogChannelId) {

          const logChannel = await message.guild.channels
            .fetch(config.spinLogChannelId)
            .catch(() => null);

          if (logChannel) {

            const logContainer = new ContainerBuilder()

              .addTextDisplayComponents(t =>
                t.setContent('إزالة نقاط')
              )

              .addSeparatorComponents(s =>
                s.setSpacing(1)
              )

              .addTextDisplayComponents(t =>
                t.setContent(
`العضو : <@${user.id}>
النقاط المزالة : ${points}
النقاط بعد الخصم : ${newPoints}
بواسطة : <@${message.author.id}>`
                )
              );

            await logChannel.send({
              ...logContainer.build(),
              flags: [MessageFlags.IsComponentsV2]
            }).catch(() => {});

          }

        }

      } catch (logErr) {
        console.error('Failed to send removepoint log:', logErr);
      }

    } catch (error) {

      console.error('Error in removepoint command:', error);

      return message.reply({
        content: 'حدث خطأ.'
      });

    }
  }
};