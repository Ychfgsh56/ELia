const { MessageFlags } = require('discord.js');
const db = require('../Utils/database');
const { ContainerBuilder, ButtonBuilder, ButtonStyle, containerToV2FullPayload } = require('../Utils/container');

module.exports = {
  name: 'spin',
  description: 'فتح واجهة العجلة',
  usage: '-spin',

  async execute(message) {
    try {

      const config = await db.getServerConfig(message.guild.id);
      const userInvites = await db.getUserInvites(message.author.id, message.guild.id);

      const container = new ContainerBuilder()

        .addTextDisplayComponents(t =>
          t.setContent('اختر نوع العجلة')
        )

        .addSeparatorComponents(s =>
          s.setSpacing(1)
        )

        .addTextDisplayComponents(t =>
          t.setContent(
`عادية : ${config.normalSpinCost} نقاط
خاصة : ${config.specialSpinCost} نقاط

نقاطك : ${userInvites}`
          )
        )

        .addSeparatorComponents(s => s.setSpacing(1))

        .addActionRowComponents(r =>
          r.setComponents(

            new ButtonBuilder()
              .setCustomId('normal_spin')
              .setLabel('عجلة عادية')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(userInvites < config.normalSpinCost),

            new ButtonBuilder()
              .setCustomId('special_spin')
              .setLabel('عجلة خاصة')
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(userInvites < config.specialSpinCost)

          )
        );

      const built = container.build();

      await message.channel.send({
        ...containerToV2FullPayload(built),
        flags: [MessageFlags.IsComponentsV2]
      });

    } catch (error) {
      console.error(error);
      return message.reply({ content: 'حدث خطأ.' });
    }
  }
};