/**
 * BlackDev Project
 * Developer: o_3_m_a_r
 * YouTube: https://www.youtube.com/@BlackDev_0
 * Discord: https://discord.com/invite/mQAWTNrcNQ
 * Copyright © o_3_m_a_r. All Rights Reserved.
 *
 * Local JSON database.
 * Each data type is stored in its own JSON file inside /data.

 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const FILES = {
  invites: path.join(DATA_DIR, 'invites.json'),
  prizes: path.join(DATA_DIR, 'prizes.json'),
  serverConfigs: path.join(DATA_DIR, 'serverConfigs.json')
};

const DEFAULTS = {
  invites: [],
  prizes: [],
  serverConfigs: []
};

const SERVER_CONFIG_DEFAULTS = {
  inviteLogChannelId: null, spinLogChannelId: null,
  normalSpinCost: 2, specialSpinCost: 3, minAccountAgeMonths: 1, wheelTheme: 'bw'
};

const writeQueues = new Map();

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function readCollection(name) {
  ensureDataDir();
  const file = FILES[name];
  if (!file) throw new Error(`Unknown database collection: ${name}`);

  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify(DEFAULTS[name], null, 2), 'utf8');
  }

  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    const fallback = DEFAULTS[name];
    fs.writeFileSync(file, JSON.stringify(fallback, null, 2), 'utf8');
    return clone(fallback);
  }
}

function writeCollection(name, records) {
  ensureDataDir();
  const file = FILES[name];
  const snapshot = JSON.stringify(records, null, 2);
  const previous = writeQueues.get(name) || Promise.resolve();
  const next = previous
    .catch(() => {})
    .then(() => fs.promises.writeFile(file, snapshot, 'utf8'));
  writeQueues.set(name, next);
  return next;
}

function makeId() {
  return `${Date.now().toString(16).slice(-10)}${Math.random().toString(16).slice(2, 16)}`
    .slice(0, 24).padEnd(24, '0');
}

function normalizeDates(record, fields) {
  if (!record) return null;
  const result = clone(record);
  for (const field of fields) {
    if (result[field]) result[field] = new Date(result[field]);
  }
  return result;
}

function normalizeBot(bot) {
  return normalizeDates(bot, ['createdAt', 'updatedAt', 'lastStarted']);
}

function matches(record, query = {}) {
  return Object.entries(query).every(([key, expected]) => {
    const actual = record[key];
    if (expected && typeof expected === 'object' && !Array.isArray(expected)) {
      if ('$in' in expected) return expected.$in.some(value => String(actual) === String(value));
      if ('$ne' in expected) return String(actual) !== String(expected.$ne);
    }
    if (Array.isArray(actual)) return actual.some(value => String(value) === String(expected));
    return String(actual) === String(expected);
  });
}

function applyUpdate(record, update = {}) {
  for (const [key, value] of Object.entries(update)) {
    if (!key.startsWith('$')) record[key] = clone(value);
  }

  if (update.$inc) {
    for (const [key, amount] of Object.entries(update.$inc)) {
      record[key] = Number(record[key] || 0) + Number(amount || 0);
    }
  }

  if (update.$addToSet) {
    for (const [key, value] of Object.entries(update.$addToSet)) {
      if (!Array.isArray(record[key])) record[key] = [];
      if (!record[key].some(item => String(item) === String(value))) record[key].push(clone(value));
    }
  }

  if (update.$pull) {
    for (const [key, value] of Object.entries(update.$pull)) {
      if (Array.isArray(record[key])) {
        record[key] = record[key].filter(item => String(item) !== String(value));
      }
    }
  }
}

async function find(name, query = {}) {
  return readCollection(name).filter(record => matches(record, query)).map(clone);
}

async function findOne(name, query = {}) {
  const record = readCollection(name).find(item => matches(item, query));
  return clone(record) || null;
}

async function create(name, values = {}, defaults = {}) {
  const records = readCollection(name);
  const now = new Date().toISOString();
  const record = { ...clone(defaults), ...clone(values), _id: values._id || makeId() };
  if (record.createdAt == null && 'createdAt' in defaults) record.createdAt = now;
  if (record.updatedAt == null && 'updatedAt' in defaults) record.updatedAt = now;
  records.push(record);
  await writeCollection(name, records);
  return clone(record);
}

async function updateOne(name, query, update, { upsert = false, defaults = {} } = {}) {
  const records = readCollection(name);
  let index = records.findIndex(record => matches(record, query));

  if (index === -1 && upsert) {
    records.push({ ...clone(defaults), ...clone(query), _id: makeId() });
    index = records.length - 1;
  }
  if (index === -1) return null;

  applyUpdate(records[index], update);
  if ('updatedAt' in defaults) records[index].updatedAt = new Date().toISOString();
  await writeCollection(name, records);
  return clone(records[index]);
}

async function deleteOne(name, query) {
  const records = readCollection(name);
  const index = records.findIndex(record => matches(record, query));
  if (index === -1) return false;
  records.splice(index, 1);
  await writeCollection(name, records);
  return true;
}

async function updateMany(name, query, update, defaults = {}) {
  const records = readCollection(name);
  let count = 0;
  for (const record of records) {
    if (!matches(record, query)) continue;
    applyUpdate(record, update);
    if ('updatedAt' in defaults) record.updatedAt = new Date().toISOString();
    count++;
  }
  if (count) await writeCollection(name, records);
  return count;
}

// ---------------- Invites ----------------
async function getUserInvites(userId, guildId) {
  const user = await findOne('invites', { userId, guildId });
  return user ? Number(user.invites || 0) : 0;
}

async function updateUserInvites(userId, guildId, newCount, invitedUserId = null) {
  if (invitedUserId) {
    const existing = await findOne('invites', { guildId, invitedUsers: invitedUserId });
    if (existing) {
      if (existing.userId === userId) return false;
      return { credited: false, existingInviterId: existing.userId };
    }
    await updateOne('invites', { userId, guildId }, {
      $inc: { invites: 1 }, $addToSet: { invitedUsers: invitedUserId }
    }, { upsert: true, defaults: { invites: 0, invitedUsers: [] } });
    return { credited: true };
  }
  await updateOne('invites', { userId, guildId }, { invites: newCount }, {
    upsert: true, defaults: { invites: 0, invitedUsers: [] }
  });
  return true;
}

async function removeInvitedUser(inviterId, guildId, invitedUserId) {
  const user = await findOne('invites', { userId: inviterId, guildId });
  if (!user || !user.invitedUsers?.includes(invitedUserId)) return false;
  await updateOne('invites', { userId: inviterId, guildId }, {
    $inc: { invites: -1 }, $pull: { invitedUsers: invitedUserId }
  }, { defaults: { invites: 0, invitedUsers: [] } });
  return true;
}

async function resetUserInvites(userId, guildId) {
  await updateOne('invites', { userId, guildId }, { invites: 0, invitedUsers: [] }, {
    upsert: true, defaults: { invites: 0, invitedUsers: [] }
  });
}

async function resetAllUserInvites(guildId) {
  await updateMany('invites', { guildId }, { invites: 0, invitedUsers: [] });
}

// ---------------- Server config ----------------
async function getServerConfig(guildId) {
  return (await findOne('serverConfigs', { guildId })) || { guildId, ...clone(SERVER_CONFIG_DEFAULTS) };
}

async function setServerConfig(guildId, inviteLogChannelId, spinLogChannelId) {
  await updateOne('serverConfigs', { guildId }, { inviteLogChannelId, spinLogChannelId }, {
    upsert: true, defaults: SERVER_CONFIG_DEFAULTS
  });
}

async function setSpinCosts(guildId, normalSpinCost, specialSpinCost) {
  await updateOne('serverConfigs', { guildId }, { normalSpinCost, specialSpinCost }, {
    upsert: true, defaults: SERVER_CONFIG_DEFAULTS
  });
}

async function setMinAccountAge(guildId, months) {
  const value = Number(months);
  const cleaned = Number.isFinite(value) && value > 0 ? Math.floor(value) : 1;
  await updateOne('serverConfigs', { guildId }, { minAccountAgeMonths: cleaned }, {
    upsert: true, defaults: SERVER_CONFIG_DEFAULTS
  });
  return true;
}

async function setWheelTheme(guildId, wheelTheme) {
  return updateOne('serverConfigs', { guildId }, { wheelTheme }, {
    upsert: true, defaults: SERVER_CONFIG_DEFAULTS
  });
}

// ---------------- Prizes ----------------
async function getPrizes(guildId, type) { return find('prizes', { guildId, type }); }
async function addOrUpdatePrize(guildId, type, value, weight) {
  await updateOne('prizes', { guildId, type, value }, { weight }, { upsert: true, defaults: {} });
}
async function removePrize(guildId, type, value) { return deleteOne('prizes', { guildId, type, value }); }

function ensureDatabase() {
  ensureDataDir();
  for (const name of Object.keys(FILES)) readCollection(name);
}

module.exports = {
  DATA_DIR,
  FILES,
  ensureDatabase,
  getUserInvites, updateUserInvites, removeInvitedUser, resetUserInvites, resetAllUserInvites,
  getServerConfig, setServerConfig, setSpinCosts, setMinAccountAge, setWheelTheme,
  getPrizes, addOrUpdatePrize, removePrize
};
