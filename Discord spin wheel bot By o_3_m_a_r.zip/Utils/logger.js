/**
 * نظام التسجيل المتقدم للبوت
 * يسجل فقط الأخطاء في ملفات أسبوعية
 */

const fs = require('fs');
const path = require('path');

// إنشاء مجلد اللوجات إذا لم يكن موجوداً
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

/**
 * الحصول على رقم الأسبوع من السنة
 */
function getWeekNumber() {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const diff = now - start;
  const oneDay = 86400000;
  const day = Math.floor(diff / oneDay);
  const week = Math.ceil((day + start.getDay() + 1) / 7);
  const year = now.getFullYear();
  return `${year}-W${String(week).padStart(2, '0')}`;
}

// ملف الأخطاء الأسبوعي فقط
const errorLogFile = path.join(logsDir, `errors-${getWeekNumber()}.log`);

/**
 * صيغة التاريخ والوقت
 */
function getTimestamp() {
  return new Date().toISOString();
}

/**
 * كتابة السجل إلى الملف (الأخطاء فقط)
 */
function writeLog(level, message, error = null) {
  const timestamp = getTimestamp();
  const logEntry = `[${timestamp}] [${level}] ${message}${error ? `\n${error.stack || error}` : ''}\n`;

  // كتابة الأخطاء فقط في ملف اللوجات الأسبوعي
  if (level === 'ERROR') {
    try {
      fs.appendFileSync(errorLogFile, logEntry, 'utf8');
    } catch (err) {
      console.error('❌ فشل كتابة الخطأ في الملف:', err.message);
    }
  }

  // الطباعة على الـ console
  switch (level) {
    case 'ERROR':
      console.error(`\x1b[31m${logEntry}\x1b[0m`); // أحمر
      break;
    case 'WARN':
      console.warn(`\x1b[33m${logEntry}\x1b[0m`); // أصفر
      break;
    case 'SUCCESS':
      console.log(`\x1b[32m${logEntry}\x1b[0m`); // أخضر
      break;
    default:
      console.log(`\x1b[36m${logEntry}\x1b[0m`); // سماوي للمعلومات
  }
}

/**
 * تسجيل رسالة تصحيح
 */
function debug(message) {
  if (process.env.DEBUG === 'true') {
    writeLog('DEBUG', message);
  }
}

/**
 * تسجيل رسالة عامة
 */
function info(message) {
  writeLog('INFO', message);
}

/**
 * تسجيل رسالة نجاح
 */
function success(message) {
  writeLog('SUCCESS', message);
}

/**
 * تسجيل رسالة تحذير
 */
function warn(message) {
  writeLog('WARN', message);
}

/**
 * تسجيل خطأ
 */
function error(message, err = null) {
  writeLog('ERROR', message, err);
}

module.exports = {
  info,
  success,
  warn,
  error,
  debug,
  writeLog,
  getWeekNumber,
  /**
   * معلومات عن نظام اللوجات
   * - يتم حفظ الأخطاء فقط في ملفات أسبوعية
   * - اسم الملف: errors-YYYY-WXX.log (مثال: errors-2026-W05.log)
   * - جميع الرسائل تظهر في console مع ألوان مختلفة
   * - فقط الأخطاء (ERROR level) يتم حفظها في الملفات
   */
};
