/**
 * BlackDev Project — o_3_m_a_r
 * Copyright © o_3_m_a_r. All Rights Reserved.
 */

const CREDITS = Object.freeze({
  developer: 'o_3_m_a_r',
  youtube: 'https://www.youtube.com/@BlackDev_0',
  discord: 'https://discord.com/invite/mQAWTNrcNQ',
  copyright: 'Copyright © o_3_m_a_r. All Rights Reserved.',
  notice: 'لا يجوز إعادة نشر المشروع أو بيعه أو نسبه إلى جهة أو شخص آخر دون إذن من المبرمج.'
});

module.exports = { CREDITS };
