/**
 * معالج الأخطاء الشامل
 * يتعامل مع جميع أنواع الأخطاء غير المتوقعة
 */

const logger = require('./logger');
const { ContainerBuilder } = require('../Utils/container');
const { MessageFlags } = require('discord.js');

class ErrorHandler {
  /**
   * معالج الأخطاء الرئيسي
   * @param {Error} error - الخطأ
   * @param {string} context - السياق (الموقع الذي حدث فيه الخطأ)
   * @param {Object} additional - معلومات إضافية
   */
  static handleError(error, context = 'Unknown', additional = {}) {
    const errorData = {
      timestamp: new Date().toISOString(),
      context,
      message: error?.message || 'Unknown error',
      stack: error?.stack || 'No stack trace',
      ...additional
    };

    // تسجيل الخطأ
    logger.error(`❌ [${context}] ${error?.message || 'Unknown error'}`, error);

    // حفظ تفاصيل الخطأ في ملف log إضافي
    this.logToFile(errorData);

    return errorData;
  }

  /**
   * معالج أخطاء التفاعلات (Interactions)
   */
  static async handleInteractionError(interaction, error, commandName = 'Unknown') {
    const errorData = this.handleError(error, `Interaction: ${commandName}`, {
      userId: interaction?.user?.id,
      guildId: interaction?.guild?.id,
      commandName
    });

    try {
      const text = `❌ حدث خطأ\n\n${errorData.message.slice(0, 100)}\n\nمعرّف الخطأ: ${errorData.timestamp}`;
      const container = new ContainerBuilder().addTextDisplayComponents(t => t.setContent(text));

      if (interaction.replied || interaction.deferred) {
        await interaction.editReply({ ...container.build(), flags: [MessageFlags.IsComponentsV2] }).catch(() => {});
      } else {
        await interaction.reply({ ...container.build(), flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] }).catch(() => {});
      }
    } catch (replyError) {
      logger.error('❌ فشل إرسال رسالة الخطأ:', replyError);
    }

    return errorData;
  }

  /**
   * معالج أخطاء الرسائل (Messages)
   */
  static async handleMessageError(message, error, commandName = 'Unknown') {
    const errorData = this.handleError(error, `Message Command: ${commandName}`, {
      userId: message?.author?.id,
      guildId: message?.guild?.id,
      commandName
    });

    try {
      await message.reply({
        content: `❌ حدث خطأ أثناء معالجة الأمر \`${commandName}\`:\n\`\`\`\n${errorData.message.slice(0, 100)}\n\`\`\``
      }).catch(() => {});
    } catch (replyError) {
      logger.error('❌ فشل إرسال رسالة الخطأ:', replyError);
    }

    return errorData;
  }

  /**
   * معالج أخطاء قاعدة البيانات
   */
  static handleDatabaseError(error, operation = 'Unknown operation') {
    return this.handleError(error, `Database: ${operation}`, {
      operation,
      isCritical: true
    });
  }

  /**
   * معالج أخطاء البوت
   */
  static handleBotError(error, context = 'Unknown') {
    const errorData = this.handleError(error, `Bot: ${context}`, {
      isCritical: true
    });

    // إذا كان الخطأ حرجاً جداً، قد نحتاج للإيقاف
    if (error?.message?.includes('authentication') || error?.message?.includes('token')) {
      logger.error('⚠️ خطأ حرج: مشكلة في المصادقة!');
    }

    return errorData;
  }

  /**
   * معالج أخطاء الشبكة
   */
  static handleNetworkError(error, context = 'Network') {
    return this.handleError(error, `Network: ${context}`, {
      isNetworkError: true
    });
  }

  /**
   * حفظ الخطأ في ملف
   */
  static logToFile(errorData) {
    try {
      const fs = require('fs');
      const path = require('path');

      const logsDir = path.join(__dirname, '../logs');
      if (!fs.existsSync(logsDir)) {
        fs.mkdirSync(logsDir, { recursive: true });
      }

      const errorLogFile = path.join(logsDir, 'errors.log');
      const logEntry = `\n\n${'='.repeat(80)}\n${JSON.stringify(errorData, null, 2)}\n${'='.repeat(80)}`;

      fs.appendFileSync(errorLogFile, logEntry, 'utf8');
    } catch (e) {
      logger.error('❌ فشل حفظ الخطأ في الملف:', e);
    }
  }

  /**
   * تنظيف الموارد عند الخطأ
   */
  static async cleanup() {
    try {
      logger.info('🧹 تنظيف الموارد...');
      // يمكن إضافة منطق التنظيف هنا
    } catch (error) {
      logger.error('❌ خطأ أثناء التنظيف:', error);
    }
  }
}

module.exports = ErrorHandler;
