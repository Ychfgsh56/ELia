/*
  Container / Components V2 implementation copied from the ticket-bot system.
  This file provides builder classes and small helpers; it does not change
  project dependencies. A compatibility helper `containerToV2FullPayload`
  is provided below to convert builders (e.g. ButtonBuilder instances)
  to plain JSON for REST posting.
*/

const {
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder
} = require('discord.js');

/* =======================
   Text Display
======================= */
class TextDisplayBuilder {
  constructor() {
    this.content = '';
  }
  setContent(content) {
    this.content = content;
    return this;
  }
  build() {
    return {
      type: 10, // Text Display
      content: this.content
    };
  }
}

/* =======================
   Media Gallery
======================= */
class MediaGalleryItemBuilder {
  constructor() {
    this.url = null;
    this.description = null;
  }
  setURL(url) {
    this.url = url;
    return this;
  }
  setDescription(desc) {
    this.description = desc;
    return this;
  }
}

class MediaGalleryBuilder {
  constructor() {
    this.items = [];
  }
  addItems(cb) {
    const item = new MediaGalleryItemBuilder();
    cb?.(item);
    if (item.url) {
      this.items.push({
        type: 1,
        media: { url: item.url },
        description: item.description ?? undefined
      });
    }
    return this;
  }
  build() {
    return {
      type: 12, // Media Gallery
      items: this.items
    };
  }
}

/* =======================
   Separator
======================= */
class SeparatorBuilder {
  constructor() {
    this.spacing = 1;
  }
  setSpacing(size) {
    this.spacing = size;
    return this;
  }
  build() {
    return {
      type: 14, // Separator
      spacing: this.spacing
    };
  }
}

/* =======================
   Action Row (V2)
======================= */
class ActionRowBuilder {
  constructor() {
    this.components = [];
  }

  setComponents(...components) {
    this.components.push(...components);
    return this;
  }

  build() {
    return {
      type: 1,
      components: this.components
    };
  }
}

/* =======================
   Container
======================= */
class ContainerBuilder {
  constructor() {
    this.components = [];
    this.accentColor = null;
  }

  setAccentColor(color) {
    this.accentColor = color;
    return this;
  }

  addTextDisplayComponents(cb) {
    const t = new TextDisplayBuilder();
    cb?.(t);
    this.components.push(t.build());
    return this;
  }

  addMediaGalleryComponents(cb) {
    const g = new MediaGalleryBuilder();
    cb?.(g);
    this.components.push(g.build());
    return this;
  }

  addSeparatorComponents(cb) {
    const s = new SeparatorBuilder();
    cb?.(s);
    this.components.push(s.build());
    return this;
  }

  addActionRowComponents(cb) {
    const r = new ActionRowBuilder();
    cb?.(r);
    this.components.push(r.build());
    return this;
  }

  build() {
    return {
      components: [
        {
          type: 17, // Container
          accent_color: this.accentColor ?? undefined,
          components: this.components
        }
      ]
    };
  }

  toJSON() {
    return this.build();
  }
}

/* =======================
   Helpers
======================= */
function containerToInteractionPayload(builtContainer) {
  const inner = builtContainer?.components?.[0]?.components || [];
  const textParts = inner.filter(c => c.type === 10).map(c => c.content).filter(Boolean);
  const content = textParts.length ? textParts.join('\n\n') : undefined;
  const rows = inner.filter(c => c.type === 1);
  const payload = {};
  if (content) payload.content = content;
  if (rows.length) payload.components = rows;
  return payload;
}

// Builds a payload compatible with Components V2 (no top-level `content`)
function containerToV2Payload(builtContainer) {
  const inner = builtContainer?.components?.[0]?.components || [];
  const rows = inner.filter(c => c.type === 1);
  const payload = {};
  if (rows.length) payload.components = rows;
  return payload;
}

// Compatibility helper: convert builder instances (e.g. ButtonBuilder)
// inside action rows to plain JSON so the result can be POSTed via REST.
function containerToV2FullPayload(builtContainer) {
  const inner = builtContainer?.components?.[0]?.components || [];
  const converted = inner.map(c => {
    if (c.type === 1) {
      const comps = Array.isArray(c.components) ? c.components.map(comp => {
        if (comp && typeof comp.toJSON === 'function') return comp.toJSON();
        return comp;
      }) : [];
      return { type: 1, components: comps };
    }
    // preserve other component types (text display, media gallery, separator)
    return c;
  });

  return {
    components: [
      {
        type: 17,
        accent_color: builtContainer?.components?.[0]?.accent_color ?? undefined,
        components: converted
      }
    ]
  };
}

/* =======================
   Export
======================= */
module.exports = {
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize: {
    Small: 1,
    Medium: 2,
    Large: 3
  },
  ActionRowBuilder,
  // Re-export discord builders commonly used with the container for consistency
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  containerToInteractionPayload,
  containerToV2Payload,
  containerToV2FullPayload
};

